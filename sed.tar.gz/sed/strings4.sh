#!/bin/bash

str="Hello, world, CentOS!"
echo "${str:(-7):4}"
