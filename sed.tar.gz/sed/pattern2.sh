#!/bin/bash

str="AAABBBCCC"
echo ${str##A*B}
