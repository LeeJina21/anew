#!/bin/bash

str="AAABBBCCC"
echo ${str%%b*c}
