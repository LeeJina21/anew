#!/bin/bash

str="Hello, world, CentOS!"
echo "${str:0:5}"

